# Lele Spreadsheet Blog Package

Paket ini membuat blog Jekyll kamu diproses dari spreadsheet Excel (`.xlsx`).

## Isi paket
- `data/blog_posts.xlsx` -> spreadsheet untuk memantau dan menyiapkan artikel
- `scripts/publish_from_spreadsheet.py` -> script yang membaca spreadsheet lalu membuat file `_posts/*.md`
- `.github/workflows/publish-from-spreadsheet.yml` -> GitHub Actions untuk publish otomatis/manual
- `requirements.txt` -> dependency Python
- `.gitignore`

## Cara pakai
1. Upload semua isi paket ini ke root repo Jekyll kamu.
2. Pastikan folder `_posts/` sudah ada.
3. Buka `data/blog_posts.xlsx`.
4. Isi baris artikel baru pada sheet **Posts**.
5. Ubah kolom **Status** menjadi `ready`.
6. Jalankan:
   - manual dari laptop:
     ```bash
     pip install -r requirements.txt
     python scripts/publish_from_spreadsheet.py
     ```
   - atau dari GitHub Actions:
     - buka tab **Actions**
     - pilih **Publish from spreadsheet**
     - klik **Run workflow**

## Struktur spreadsheet
### Sheet: Posts
Kolom yang dipakai:
- `ID` : nomor internal
- `Status` : `draft`, `ready`, `published`, `error`
- `Publish Date` : tanggal posting
- `Title` : judul artikel
- `Slug` : URL slug (contoh: `tips-bromo-musim-hujan`)
- `Category` : kategori utama
- `Tags` : pisahkan dengan koma
- `Excerpt` : ringkasan singkat
- `Featured Image` : URL gambar utama (opsional)
- `Layout` : default `post`
- `Author` : opsional
- `Content (Markdown)` : isi artikel markdown
- `Filename Preview` : otomatis dari formula
- `Validation` : otomatis dari formula
- `Published At` : diisi script saat berhasil publish
- `Post Path` : diisi script
- `Result` : log hasil terakhir

### Sheet: Config
Beberapa default yang bisa diubah:
- `layout_default`
- `timezone_offset`
- `default_category`
- `posts_directory`
- `overwrite_existing`
- `author_default`

## Alur publish
- row dengan status `draft` -> diabaikan
- row dengan status `ready` -> dibuat jadi file post
- setelah berhasil -> status berubah jadi `published`

## Contoh nama file hasil
Jika tanggal `2026-03-25` dan slug `tips-bromo-musim-hujan`, maka file jadi:
```text
_posts/2026-03-25-tips-bromo-musim-hujan.md
```

## Catatan penting
- Paket ini **tidak mengubah post lama**
- Paket ini hanya membuat **post baru**
- Secara default workflow GitHub Actions diset **manual dulu** agar aman untuk blog yang sudah live
- Kalau nanti mau otomatis harian/mingguan, tinggal aktifkan bagian `schedule` di file workflow

## Saran penggunaan
Untuk blog yang sudah live dan terindeks:
- isi artikel di spreadsheet
- review dulu
- baru set `Status = ready`
- jalankan workflow manual

Kalau nanti kamu mau versi lanjutan, paket ini bisa di-upgrade ke:
- Google Sheets
- scheduling per jam
- SEO fields tambahan
- auto-generate image/front matter tambahan
- publish/update mode
